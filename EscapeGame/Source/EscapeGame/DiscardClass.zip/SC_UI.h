// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Sound/SoundClass.h"
#include "SC_UI.generated.h"

/**
 * 
 */
UCLASS()
class ESCAPEGAME_API USC_UI : public USoundClass
{
	GENERATED_BODY()
	
};
