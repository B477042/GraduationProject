// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Sound/SoundClass.h"
#include "SC_SE.generated.h"

/**
 * 
 */
UCLASS()
class ESCAPEGAME_API USC_SE : public USoundClass
{
	GENERATED_BODY()
	
};
